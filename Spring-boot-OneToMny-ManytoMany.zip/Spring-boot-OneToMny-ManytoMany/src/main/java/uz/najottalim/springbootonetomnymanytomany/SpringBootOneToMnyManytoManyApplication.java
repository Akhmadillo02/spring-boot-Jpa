package uz.najottalim.springbootonetomnymanytomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneToMnyManytoManyApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootOneToMnyManytoManyApplication.class, args);
    }

}
