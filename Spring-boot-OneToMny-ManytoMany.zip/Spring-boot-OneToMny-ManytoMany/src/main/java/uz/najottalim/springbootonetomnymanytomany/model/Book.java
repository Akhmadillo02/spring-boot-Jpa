package uz.najottalim.springbootonetomnymanytomany.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String publisherDate;

    private Double price;

    @OneToMany
    private List<Category>categories;

    @ManyToOne
    private Author authors;

    @ManyToOne
    private Publisher publisher;

    @ManyToMany
    private List<Tag>tags;


}
